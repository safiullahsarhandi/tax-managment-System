<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerEmployee extends Model {
	//
	protected $table = 'customers_employees';
}
