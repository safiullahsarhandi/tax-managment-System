(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[56],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/MemberDetail.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/MemberDetail.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])('admins/', ['member'])),
  created: function created() {
    this.getMemberDetail(this.$route.params.id);
  },
  methods: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapActions"])({
    getMemberDetail: 'admins/getMemberDetail'
  }))
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/MemberDetail.vue?vue&type=template&id=520994c0&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/MemberDetail.vue?vue&type=template&id=520994c0& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "vx-card",
        { attrs: { title: "Member Detail" } },
        [
          _c(
            "vs-row",
            [
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-edit" }
                      }),
                      _vm._v("First Name")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.first_name))])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-edit" }
                      }),
                      _vm._v("Last Name")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.last_name))])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-mail" }
                      }),
                      _vm._v("Email")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.email))])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-male" }
                      }),
                      _vm._v("Gender")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.gender))])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-phone" }
                      }),
                      _vm._v("Phone")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.phone))])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-map-pin" }
                      }),
                      _vm._v("Address")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [
                    _vm._v(
                      _vm._s(_vm.member.address) +
                        " " +
                        _vm._s(_vm.member.state) +
                        " " +
                        _vm._s(_vm.member.city) +
                        " " +
                        _vm._s(_vm.member.zip_code)
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-clock" }
                      }),
                      _vm._v("Registered at")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [
                    _vm._v(
                      _vm._s(
                        new Date(_vm.member.created_at).toLocaleDateString()
                      )
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-check" }
                      }),
                      _vm._v("Account Status")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [
                    _vm._v(
                      _vm._s(
                        _vm.member.status == 1 ? "Approved" : "Dis Approved"
                      )
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-" }
                      }),
                      _vm._v("Total Taxes Managed")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.taxes_count))])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                {
                  staticClass: "mt-4",
                  attrs: { "vs-md": "4", "vs-lg": "4", "vs-xl": "4" }
                },
                [
                  _c(
                    "label",
                    [
                      _c("vs-icon", {
                        attrs: { "icon-pack": "feather", icon: "icon-" }
                      }),
                      _vm._v("Total Taxes Managing")
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("h5", [_vm._v(_vm._s(_vm.member.active_taxes))])
                ]
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "vx-card",
        {
          staticClass: "mt-base",
          attrs: { title: "Managed OR Managing Taxes" }
        },
        [
          _c(
            "vs-table",
            {
              attrs: { data: _vm.member.taxes },
              scopedSlots: _vm._u([
                {
                  key: "default",
                  fn: function(ref) {
                    var data = ref.data
                    return _vm._l(data, function(tr, index) {
                      return _c(
                        "vs-tr",
                        { key: tr.id },
                        [
                          _c("vs-td", [_vm._v(_vm._s(tr.tax.title))]),
                          _vm._v(" "),
                          _c("vs-td", [_vm._v(_vm._s(tr.tax.duration))]),
                          _vm._v(" "),
                          _c("vs-td", [_vm._v(_vm._s(tr.tax.type))]),
                          _vm._v(" "),
                          _c("vs-td", [
                            _vm._v(_vm._s(tr.tax.supervisor.full_name))
                          ]),
                          _vm._v(" "),
                          _c("vs-td", [
                            _vm._v(
                              _vm._s(tr.tax.status ? "In Progess" : "Completed")
                            )
                          ])
                        ],
                        1
                      )
                    })
                  }
                }
              ])
            },
            [
              _c(
                "template",
                { slot: "thead" },
                [
                  _c("vs-th", [_vm._v("Title")]),
                  _vm._v(" "),
                  _c("vs-th", [_vm._v("Duration")]),
                  _vm._v(" "),
                  _c("vs-th", [_vm._v("Tax Type")]),
                  _vm._v(" "),
                  _c("vs-th", [_vm._v("Reports To")]),
                  _vm._v(" "),
                  _c("vs-th", [_vm._v("Work Status")])
                ],
                1
              )
            ],
            2
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/pages/MemberDetail.vue":
/*!*******************************************************!*\
  !*** ./resources/js/src/views/pages/MemberDetail.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MemberDetail_vue_vue_type_template_id_520994c0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MemberDetail.vue?vue&type=template&id=520994c0& */ "./resources/js/src/views/pages/MemberDetail.vue?vue&type=template&id=520994c0&");
/* harmony import */ var _MemberDetail_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MemberDetail.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/MemberDetail.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _MemberDetail_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _MemberDetail_vue_vue_type_template_id_520994c0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _MemberDetail_vue_vue_type_template_id_520994c0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/MemberDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/MemberDetail.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/src/views/pages/MemberDetail.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_MemberDetail_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./MemberDetail.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/MemberDetail.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_MemberDetail_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/MemberDetail.vue?vue&type=template&id=520994c0&":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/pages/MemberDetail.vue?vue&type=template&id=520994c0& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_MemberDetail_vue_vue_type_template_id_520994c0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./MemberDetail.vue?vue&type=template&id=520994c0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/MemberDetail.vue?vue&type=template&id=520994c0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_MemberDetail_vue_vue_type_template_id_520994c0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_MemberDetail_vue_vue_type_template_id_520994c0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);