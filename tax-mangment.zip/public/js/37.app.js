(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[37],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Companies/Customers.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Companies/Customers.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  created: function created() {
    this.getOwners();
  },
  data: function data() {
    return {
      owner_id: '',
      showAddOwnerPopup: false,
      name_english: '',
      name_khmer: '',
      email: '',
      phone_number: '',
      nic: '',
      showEditOwnerPopup: false,
      edit_name_english: '',
      edit_name_khmer: '',
      edit_email: '',
      edit_phone_number: '',
      edit_nic: ''
    };
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])('customers/', ['owners']), {}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])('customers/', ['findOwner'])),
  methods: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapActions"])({
    getOwners: 'customers/getOwners',
    createOwner: 'customers/createOwner',
    updateOwner: 'customers/updateOwner'
  }), {
    addOwner: function addOwner(e, scope) {
      var _this = this;

      this.$validator.validateAll(scope).then(function (result) {
        if (result) {
          var fd = new FormData(_this.$refs.addform);
          var data = {
            fd: fd,
            notify: _this.$vs.notify
          };

          _this.createOwner(data).then(function (res) {
            if (res.data.status == 'success') {
              _this.name_khmer = _this.name_english = _this.nic = _this.email = _this.phone_number = '';
              e.target.reset();

              _this.$validator.reset();

              _this.showAddOwnerPopup = false;

              _this.getOwners();
            }
          });
        }
      });
    },
    showUpdateScreen: function showUpdateScreen(owner_id, index) {
      var owner = this.findOwner(owner_id);
      this.owner_id = owner.owner_id;
      this.edit_nic = owner.nic;
      this.edit_name_english = owner.name_english;
      this.edit_name_khmer = owner.name_khmer;
      this.edit_phone_number = owner.phone_number;
      this.edit_email = owner.email;
      this.showEditOwnerPopup = true;
    },
    editOwner: function editOwner(e, scope) {
      var _this2 = this;

      this.$validator.validateAll(scope).then(function (result) {
        if (result) {
          var fd = new FormData(_this2.$refs.editform);
          fd.append('owner_id', _this2.owner_id);
          var data = {
            fd: fd,
            notify: _this2.$vs.notify
          };

          _this2.updateOwner(data).then(function (res) {
            if (res.data.status == 'success') {
              _this2.edit_name_khmer = _this2.edit_name_english = _this2.edit_nic = _this2.edit_email = _this2.edit_phone_number = '';
              e.target.reset();

              _this2.$validator.reset();

              _this2.showEditOwnerPopup = false;
            }
          });
        }
      });
    }
  })
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Companies/Customers.vue?vue&type=template&id=6652837c&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Companies/Customers.vue?vue&type=template&id=6652837c& ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "vs-row",
        [
          _c(
            "vs-col",
            { attrs: { "vs-md": "12", "vs-lg": "12", "vs-xs": "12" } },
            [
              _c(
                "vx-card",
                {
                  attrs: {
                    title: "List Of Customers",
                    subtitle: "List Of Owners Who Own Companies in our System"
                  }
                },
                [
                  _c(
                    "template",
                    { slot: "actions" },
                    [
                      _c("vs-button", {
                        attrs: {
                          type: "gradient",
                          "icon-pack": "feather",
                          icon: "icon-plus"
                        },
                        on: {
                          click: function($event) {
                            _vm.showAddOwnerPopup = true
                          }
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-table",
                    {
                      attrs: {
                        search: "",
                        pagination: "",
                        "max-items": 10,
                        data: _vm.owners
                      },
                      scopedSlots: _vm._u([
                        {
                          key: "default",
                          fn: function(ref) {
                            var data = ref.data
                            return _vm._l(data, function(tr, index) {
                              return _c(
                                "vs-tr",
                                { key: index },
                                [
                                  _c("vs-td", [
                                    _vm._v(_vm._s(tr.name_english))
                                  ]),
                                  _vm._v(" "),
                                  _c("vs-td", [_vm._v(_vm._s(tr.name_khmer))]),
                                  _vm._v(" "),
                                  _c("vs-td", [_vm._v(_vm._s(tr.email))]),
                                  _vm._v(" "),
                                  _c("vs-td", [
                                    _vm._v(_vm._s(tr.companies_count))
                                  ]),
                                  _vm._v(" "),
                                  _c("vs-td", [
                                    _vm._v(_vm._s(tr.phone_number))
                                  ]),
                                  _vm._v(" "),
                                  _c("vs-td", [_vm._v(_vm._s(tr.nic))]),
                                  _vm._v(" "),
                                  _c(
                                    "vs-td",
                                    [
                                      _c("vs-button", {
                                        attrs: {
                                          "icon-pack": "feather",
                                          type: "gradient",
                                          icon: "icon-edit"
                                        },
                                        on: {
                                          click: function($event) {
                                            return _vm.showUpdateScreen(
                                              tr.owner_id,
                                              index
                                            )
                                          }
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            })
                          }
                        }
                      ])
                    },
                    [
                      _c(
                        "template",
                        { slot: "thead" },
                        [
                          _c("vs-th", [_vm._v("Customer Name (English)")]),
                          _vm._v(" "),
                          _c("vs-th", [_vm._v("Customer Name (Khmer)")]),
                          _vm._v(" "),
                          _c("vs-th", [_vm._v("Email")]),
                          _vm._v(" "),
                          _c("vs-th", [_vm._v("No. Of Companies")]),
                          _vm._v(" "),
                          _c("vs-th", [_vm._v("Phone Number")]),
                          _vm._v(" "),
                          _c("vs-th", [_vm._v("NIC #")]),
                          _vm._v(" "),
                          _c("vs-th", [_vm._v("Action")])
                        ],
                        1
                      )
                    ],
                    2
                  )
                ],
                2
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "vs-popup",
        {
          attrs: { title: "Add Customer", active: _vm.showAddOwnerPopup },
          on: {
            "update:active": function($event) {
              _vm.showAddOwnerPopup = $event
            }
          }
        },
        [
          _c(
            "form",
            {
              ref: "addform",
              attrs: { "data-vv-scope": "addform" },
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.addOwner($event, "addform")
                }
              }
            },
            [
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Name (English)",
                              type: "text",
                              name: "name_english",
                              "data-vv-as": "name (English)"
                            },
                            model: {
                              value: _vm.name_english,
                              callback: function($$v) {
                                _vm.name_english = $$v
                              },
                              expression: "name_english"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("addform.name_english"),
                              expression: "errors.has('addform.name_english')"
                            }
                          ]
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("addform.name_english"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Name (Khmer)",
                              type: "text",
                              name: "name_khmer",
                              "data-vv-as": "name (Khmer)"
                            },
                            model: {
                              value: _vm.name_khmer,
                              callback: function($$v) {
                                _vm.name_khmer = $$v
                              },
                              expression: "name_khmer"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("addform.name_khmer"),
                              expression: "errors.has('addform.name_khmer')"
                            }
                          ]
                        },
                        [_vm._v(_vm._s(_vm.errors.first("addform.name_khmer")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required|email",
                                expression: "'required|email'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Email",
                              type: "email",
                              name: "email"
                            },
                            model: {
                              value: _vm.email,
                              callback: function($$v) {
                                _vm.email = $$v
                              },
                              expression: "email"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("addform.email"),
                              expression: "errors.has('addform.email')"
                            }
                          ]
                        },
                        [_vm._v(_vm._s(_vm.errors.first("addform.email")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required|numeric",
                                expression: "'required|numeric'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Phone",
                              type: "text",
                              "data-vv-as": "Phone Number",
                              name: "phone_number"
                            },
                            model: {
                              value: _vm.phone_number,
                              callback: function($$v) {
                                _vm.phone_number = $$v
                              },
                              expression: "phone_number"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("addform.phone_numer"),
                              expression: "errors.has('addform.phone_numer')"
                            }
                          ]
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("addform.phone_numer"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "NIC",
                              type: "text",
                              name: "nic"
                            },
                            model: {
                              value: _vm.nic,
                              callback: function($$v) {
                                _vm.nic = $$v
                              },
                              expression: "nic"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("addform.nic"),
                              expression: "errors.has('addform.nic')"
                            }
                          ]
                        },
                        [_vm._v(_vm._s(_vm.errors.first("addform.nic")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3 flex justify-end",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vs-button",
                        { attrs: { button: "submit", type: "gradient" } },
                        [_vm._v("Add Customer")]
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "vs-popup",
        {
          attrs: { title: "Update Customer", active: _vm.showEditOwnerPopup },
          on: {
            "update:active": function($event) {
              _vm.showEditOwnerPopup = $event
            }
          }
        },
        [
          _c(
            "form",
            {
              ref: "editform",
              attrs: { "data-vv-scope": "editform" },
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.editOwner($event, "editform")
                }
              }
            },
            [
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Name (English)",
                              type: "text",
                              name: "name_english",
                              "data-vv-as": "name (English)"
                            },
                            model: {
                              value: _vm.edit_name_english,
                              callback: function($$v) {
                                _vm.edit_name_english = $$v
                              },
                              expression: "edit_name_english"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("editform.name_english"),
                              expression: "errors.has('editform.name_english')"
                            }
                          ]
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("editform.name_english"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Name (Khmer)",
                              type: "text",
                              name: "name_khmer",
                              "data-vv-as": "name (Khmer)"
                            },
                            model: {
                              value: _vm.edit_name_khmer,
                              callback: function($$v) {
                                _vm.edit_name_khmer = $$v
                              },
                              expression: "edit_name_khmer"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("editform.name_khmer"),
                              expression: "errors.has('editform.name_khmer')"
                            }
                          ]
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("editform.name_khmer"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required|email",
                                expression: "'required|email'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Email",
                              type: "email",
                              name: "email"
                            },
                            model: {
                              value: _vm.edit_email,
                              callback: function($$v) {
                                _vm.edit_email = $$v
                              },
                              expression: "edit_email"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("editform.email"),
                              expression: "errors.has('editform.email')"
                            }
                          ]
                        },
                        [_vm._v(_vm._s(_vm.errors.first("editform.email")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required|numeric",
                                expression: "'required|numeric'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "Phone",
                              type: "text",
                              "data-vv-as": "Phone Number",
                              name: "phone_number"
                            },
                            model: {
                              value: _vm.edit_phone_number,
                              callback: function($$v) {
                                _vm.edit_phone_number = $$v
                              },
                              expression: "edit_phone_number"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("editform.phone_numer"),
                              expression: "errors.has('editform.phone_numer')"
                            }
                          ]
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("editform.phone_numer"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'"
                              }
                            ],
                            attrs: {
                              "label-placeholder": "NIC",
                              type: "text",
                              name: "nic"
                            },
                            model: {
                              value: _vm.edit_nic,
                              callback: function($$v) {
                                _vm.edit_nic = $$v
                              },
                              expression: "edit_nic"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("editform.nic"),
                              expression: "errors.has('editform.nic')"
                            }
                          ]
                        },
                        [_vm._v(_vm._s(_vm.errors.first("editform.nic")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-3 flex justify-end",
                      attrs: { "vs-md": "12", "vs-lg": "12", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vs-button",
                        { attrs: { button: "submit", type: "gradient" } },
                        [_vm._v("Update Customer")]
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/pages/Companies/Customers.vue":
/*!**************************************************************!*\
  !*** ./resources/js/src/views/pages/Companies/Customers.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Customers_vue_vue_type_template_id_6652837c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Customers.vue?vue&type=template&id=6652837c& */ "./resources/js/src/views/pages/Companies/Customers.vue?vue&type=template&id=6652837c&");
/* harmony import */ var _Customers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Customers.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/Companies/Customers.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Customers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Customers_vue_vue_type_template_id_6652837c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Customers_vue_vue_type_template_id_6652837c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/Companies/Customers.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/Companies/Customers.vue?vue&type=script&lang=js&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/pages/Companies/Customers.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Customers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Customers.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Companies/Customers.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Customers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/Companies/Customers.vue?vue&type=template&id=6652837c&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/pages/Companies/Customers.vue?vue&type=template&id=6652837c& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Customers_vue_vue_type_template_id_6652837c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Customers.vue?vue&type=template&id=6652837c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Companies/Customers.vue?vue&type=template&id=6652837c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Customers_vue_vue_type_template_id_6652837c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Customers_vue_vue_type_template_id_6652837c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);