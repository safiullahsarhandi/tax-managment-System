(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[48],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
var multiUploads = function multiUploads() {
  return __webpack_require__.e(/*! import() */ 1).then(__webpack_require__.bind(null, /*! @/components/MultiUploads.vue */ "./resources/js/src/components/MultiUploads.vue"));
};


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      multipleUploadPopup: false,
      customField: [],
      account_code: '',
      account_description: '',
      account_ref: '',
      sign_date: '',
      branch_name: '',
      tax_period: '',
      invoice_date: '',
      invoice_number: '',
      client_name: '',
      client_tin: '',
      description: '',
      quantity: '',
      non_taxable_sales: '',
      export_value: '',
      person_non_taxable_sales: '',
      person_export_value: 0,
      customer_non_taxable_sales: '',
      customer_export_value: 0,
      total_taxable_value: 0,
      item_subject_taxes: '',
      comments_3e_fii: '',
      client_responses: '',
      comments_for_top: '',
      tax_id: '',
      customer_id: '',
      multipleRoute: '',
      params: [],
      totalVat: 0
    };
  },
  components: {
    multiUploads: multiUploads
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])('customers', ['customer']), {}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])('taxes', ['parameters']), {
    averageRate: function averageRate() {
      return this.$store.state.averageRate;
    }
  }),
  watch: {
    person_non_taxable_sales: function person_non_taxable_sales(val, oldVal) {
      this.setTotalVat();
      this.setTotalTaxableValue();
    },
    customer_non_taxable_sales: function customer_non_taxable_sales(val, oldVal) {
      this.setTotalVat();
      this.setTotalTaxableValue();
    },
    non_taxable_sales: function non_taxable_sales(val, oldVal) {
      this.setTotalTaxableValue();
    },
    export_value: function export_value(val, oldVal) {
      this.setTotalTaxableValue();
    }
  },
  created: function created() {
    this.tax_id = this.$store.state.rootUrl.split('/')[2];
    this.customer_id = localStorage.getItem('customer');
    this.$store.dispatch('getAverageRate');
    this.getCustomer(this.customer_id);
    var loginUserId;
    var loginUsertype;

    if (this.$store.state.AppActiveUser.type == 'Supervisor') {
      loginUsertype = 'supervisor';
    } else {
      loginUsertype = 'officer';
    }

    loginUserId = this.$store.state.AppActiveUser.manager_id; // console.log(loginUserId)

    this.multipleRoute = 'add-multiple-sales/' + this.customer_id + '/' + this.tax_id + '/' + loginUsertype + '/' + loginUserId;
    var self = this;
    this.getParameters().then(function () {
      _.each(self.parameters, function (o) {
        if (o.tax_code == 'PPT' || o.tax_code == 'VAT') {
          self.params.push(o);
        }
      });
    });
  },
  methods: _objectSpread({
    setTotalVat: function setTotalVat() {
      this.totalVat = this.customer_non_taxable_sales + this.person_non_taxable_sales;
    },
    setTotalTaxableValue: function setTotalTaxableValue() {
      /*var taxable_value = (this.person_non_taxable_sales * this.averageRate);
      var person_non_taxable_val = (taxable_value + (taxable_value * 0.1));
        var taxable_value = (this.customer_non_taxable_sales * this.averageRate);
      var customer_non_taxable_val = (taxable_value + (taxable_value * 0.1));
        var non_taxable_sale = (this.non_taxable_sales * this.averageRate);
      var export_value = (this.export_value * this.averageRate);*/
      // end

      /*var person_non_taxable_val = ();
      var person_non_taxable_val = (taxable_value + (taxable_value * 0.1));
        var taxable_value = ( * this.averageRate);
      var customer_non_taxable_val = (taxable_value + (taxable_value * 0.1));
        var non_taxable_sale = ( * this.averageRate);
      var export_value = ( * this.averageRate);*/
      this.total_taxable_value = (this.person_non_taxable_sales + this.customer_non_taxable_sales + this.non_taxable_sales + this.export_value) * this.averageRate;
    },
    calculateTaxParams: function calculateTaxParams() {
      var _this = this;

      _.each(this.params, function (o) {
        if (o.tax_code == 'PPT') {
          o.calculated_val = Math.round(_this.total_taxable_value * o.base_tax * o.rate);
        } else if (o.tax_code == 'VAT') {
          o.calculated_val = _this.totalVat * _this.averageRate * o.rate;
        }
      });
    },
    showUploader: function showUploader() {
      this.$refs.multiUploads.isShown = true;
    },
    checkSelectedValues: function checkSelectedValues(param) {
      return true;
    },
    getSelected: function getSelected(values) {
      var selectedTaxes = _.filter(values, function (o) {
        if (o.tax_code == 'PPT' || o.tax_code == 'VAT') {
          return o;
        }
      }); // console.log(selectedTaxes);

    },
    addMoreFeild: function addMoreFeild() {
      this.customField.push({
        name: 'additional_fields[]',
        value: '',
        type: 'text'
      });
    },
    hasError: function hasError(res) {
      this.$vs.notify({
        color: 'danger',
        text: res.msg,
        position: 'right-top',
        fixed: true
      });
    },
    successMultipleUpload: function successMultipleUpload(res) {
      this.$vs.notify({
        color: 'success',
        text: res.msg,
        position: 'right-top',
        fixed: true
      });
      this.$refs.multiUploads.isShown = false;
    }
  }, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapActions"])({
    submit: 'sales/addSale',
    getCustomer: 'customers/getCustomer',
    getParameters: 'taxes/getParameters'
  }), {
    addForm: function addForm(e) {
      var _this2 = this;

      this.$validator.validateAll().then(function (result) {
        if (result) {
          _this2.$vs.loading();

          var fd = new FormData(_this2.$refs.addForm);
          fd.append('tax_id', _this2.tax_id);
          fd.append('customer_id', _this2.customer_id);
          fd.append('created_by', _this2.$store.state.AppActiveUser.manager_id);
          fd.append('creator_type', _this2.$store.state.AppActiveUser.type);
          /*if (this.$store.state.AppActiveUser.type == 'Supervisor') {
          } else {
              fd.append('officer_id', this.$store.state.AppActiveUser.manager_id);
          }*/

          _this2.submit(fd).then(function (res) {
            if (res.data.status == 'success') {
              e.target.reset();

              _this2.errors.clear();

              _this2.$vs.notify({
                title: 'Success',
                text: 'Sale Added Successfully',
                color: 'success',
                position: 'top-right'
              });

              _this2.$vs.loading.close();
            }

            if (res.data.status == 'error') {
              alert(res.data.msg);
            }
          });
        }
      });
    }
  })
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=template&id=6faed120&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=template&id=6faed120& ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("multi-uploads", {
        ref: "multiUploads",
        attrs: {
          action: _vm.multipleRoute,
          "sample-url": "./public/samples/sale.xlsx",
          active: _vm.multipleUploadPopup
        },
        on: { error: _vm.hasError, uploaded: _vm.successMultipleUpload }
      }),
      _vm._v(" "),
      _c(
        "vx-card",
        { attrs: { title: "Add Sale", noShadow: "", noRadius: "" } },
        [
          _c(
            "template",
            { slot: "actions" },
            [
              _c(
                "vs-button",
                {
                  staticClass: "mt-5",
                  attrs: { type: "gradient", button: "button" },
                  on: {
                    click: function($event) {
                      return _vm.showUploader()
                    }
                  }
                },
                [_vm._v("Upload Excel Sheet")]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "form",
            {
              ref: "addForm",
              attrs: { autocomplete: "off" },
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.addForm($event)
                }
              }
            },
            [
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "account_code",
                              "data-vv-as": "Account Code",
                              "label-placeholder": "Account Code"
                            },
                            model: {
                              value: _vm.account_code,
                              callback: function($$v) {
                                _vm.account_code = $$v
                              },
                              expression: "account_code"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("account_code"),
                              expression: "errors.has('account_code')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("account_code")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "account_description",
                              "data-vv-as": "Account Description",
                              "label-placeholder": "Account Description"
                            },
                            model: {
                              value: _vm.account_description,
                              callback: function($$v) {
                                _vm.account_description = $$v
                              },
                              expression: "account_description"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("account_description"),
                              expression: "errors.has('account_description')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("account_description"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "accounting_reference",
                              "data-vv-as": "Account Reference",
                              "label-placeholder": "Account Reference"
                            },
                            model: {
                              value: _vm.account_ref,
                              callback: function($$v) {
                                _vm.account_ref = $$v
                              },
                              expression: "account_ref"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("accounting_reference"),
                              expression: "errors.has('accounting_reference')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("accounting_reference"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "signature_date",
                              "data-vv-as": "Signature Date",
                              "label-placeholder": "Signature Date"
                            },
                            model: {
                              value: _vm.sign_date,
                              callback: function($$v) {
                                _vm.sign_date = $$v
                              },
                              expression: "sign_date"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("signature_date"),
                              expression: "errors.has('signature_date')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("signature_date")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "branch_name",
                              "data-vv-as": "Branch Name",
                              "label-placeholder": "Branch#/Name"
                            },
                            model: {
                              value: _vm.branch_name,
                              callback: function($$v) {
                                _vm.branch_name = $$v
                              },
                              expression: "branch_name"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("branch_name"),
                              expression: "errors.has('branch_name')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("branch_name")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "tax_period",
                              "data-vv-as": "Tax Period",
                              "label-placeholder": "Tax Period"
                            },
                            model: {
                              value: _vm.tax_period,
                              callback: function($$v) {
                                _vm.tax_period = $$v
                              },
                              expression: "tax_period"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("tax_period"),
                              expression: "errors.has('tax_period')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("tax_period")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "invoice_date",
                              "data-vv-as": "Invoice Date",
                              "label-placeholder": "Invoice Date"
                            },
                            model: {
                              value: _vm.invoice_date,
                              callback: function($$v) {
                                _vm.invoice_date = $$v
                              },
                              expression: "invoice_date"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("invoice_date"),
                              expression: "errors.has('invoice_date')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("invoice_date")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "invoice_num",
                              "data-vv-as": "Invoice No. / Credit Note No.",
                              "label-placeholder":
                                "Invoice No./ Credit Note No."
                            },
                            model: {
                              value: _vm.invoice_number,
                              callback: function($$v) {
                                _vm.invoice_number = $$v
                              },
                              expression: "invoice_number"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("invoice_num"),
                              expression: "errors.has('invoice_num')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("invoice_num")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "client_name",
                              "label-placeholder": "Client Name"
                            },
                            model: {
                              value: _vm.customer.name_english,
                              callback: function($$v) {
                                _vm.$set(_vm.customer, "name_english", $$v)
                              },
                              expression: "customer.name_english"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "client_tin",
                              "label-placeholder": "Client TIN"
                            },
                            model: {
                              value: _vm.customer.tin_no,
                              callback: function($$v) {
                                _vm.$set(_vm.customer, "tin_no", $$v)
                              },
                              expression: "customer.tin_no"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "description",
                              "data-vv-as": "Description",
                              "label-placeholder": "Description"
                            },
                            model: {
                              value: _vm.description,
                              callback: function($$v) {
                                _vm.description = $$v
                              },
                              expression: "description"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("description"),
                              expression: "errors.has('description')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("description")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "quantity",
                              "data-vv-as": "Quantity",
                              "label-placeholder": "Quantity"
                            },
                            model: {
                              value: _vm.quantity,
                              callback: function($$v) {
                                _vm.quantity = $$v
                              },
                              expression: "quantity"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("quantity"),
                              expression: "errors.has('quantity')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("quantity")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "decimal",
                                expression: "`decimal`"
                              }
                            ],
                            attrs: {
                              name: "non_taxable_sales",
                              "data-vv-as": "Non-Taxable Sales",
                              "label-placeholder": "Non-Taxable Sales"
                            },
                            model: {
                              value: _vm.non_taxable_sales,
                              callback: function($$v) {
                                _vm.non_taxable_sales = $$v
                              },
                              expression: "non_taxable_sales"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("non_taxable_sales"),
                              expression: "errors.has('non_taxable_sales')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("non_taxable_sales")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "vat",
                              "data-vv-as": "Value of Exports / 0% VAT",
                              "label-placeholder": "Value of Exports/ 0% VAT"
                            },
                            model: {
                              value: _vm.export_value,
                              callback: function($$v) {
                                _vm.export_value = $$v
                              },
                              expression: "export_value"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("vat"),
                              expression: "errors.has('vat')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("vat")))]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("br"),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c("label", [_vm._v("Sales to Taxable Persons")]),
                      _vm._v(" "),
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "decimal",
                                expression: "'decimal'"
                              }
                            ],
                            attrs: {
                              name: "taxable_person_sales",
                              "data-vv-as": "Non-Taxable Sales",
                              "label-placeholder": "Non-Taxable Sales"
                            },
                            model: {
                              value: _vm.person_non_taxable_sales,
                              callback: function($$v) {
                                _vm.person_non_taxable_sales = $$v
                              },
                              expression: "person_non_taxable_sales"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("taxable_person_sales"),
                              expression: "errors.has('taxable_person_sales')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("taxable_person_sales"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c("label", [_vm._v("Sales to Customers")]),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "decimal",
                                expression: "'decimal'"
                              }
                            ],
                            attrs: {
                              name: "cust_sales",
                              "data-vv-as": "Non-Taxable Sales",
                              "label-placeholder": "Non-Taxable Sales"
                            },
                            model: {
                              value: _vm.customer_non_taxable_sales,
                              callback: function($$v) {
                                _vm.customer_non_taxable_sales = $$v
                              },
                              expression: "customer_non_taxable_sales"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("cust_sales"),
                              expression: "errors.has('cust_sales')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("cust_sales")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-5",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "total_taxable_value",
                              "data-vv-as": "Total Taxable Value",
                              "label-placeholder": "Total Taxable Value"
                            },
                            model: {
                              value: _vm.total_taxable_value,
                              callback: function($$v) {
                                _vm.total_taxable_value = $$v
                              },
                              expression: "total_taxable_value"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("total_taxable_value"),
                              expression: "errors.has('total_taxable_value')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("total_taxable_value"))
                          )
                        ]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("vs-divider", [_vm._v("Tax Parameters")]),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "flex justify-end",
                      attrs: {
                        "vs-lg": "12",
                        "vs-md": "12",
                        "vs-sm": "12",
                        "vs-xs": "12"
                      }
                    },
                    [
                      _c("vs-button", {
                        attrs: {
                          type: "border",
                          icon: "icon-refresh-ccw",
                          "icon-pack": "feather"
                        },
                        on: { click: _vm.calculateTaxParams }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm._l(_vm.params, function(param, index) {
                    return _c(
                      "vs-col",
                      {
                        key: index,
                        attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                      },
                      [
                        _c(
                          "vx-input-group",
                          [
                            _c("vs-input", {
                              attrs: {
                                disabled: "",
                                name: "param",
                                "label-placeholder": param.tax_param_id
                              },
                              model: {
                                value: param.calculated_val,
                                callback: function($$v) {
                                  _vm.$set(param, "calculated_val", $$v)
                                },
                                expression: "param.calculated_val"
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
                  })
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mt-5",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c(
                            "vs-select",
                            {
                              attrs: {
                                width: "100%",
                                "label-placeholder": "Item subject to taxes",
                                multiple: "",
                                name: "params"
                              },
                              on: { input: _vm.getSelected },
                              model: {
                                value: _vm.params,
                                callback: function($$v) {
                                  _vm.params = $$v
                                },
                                expression: "params"
                              }
                            },
                            _vm._l(_vm.parameters, function(param, index) {
                              return _c("vs-select-item", {
                                key: index,
                                attrs: {
                                  disabled:
                                    param.tax_code == "PPT" ||
                                    param.tax_code == "VAT",
                                  text: param.tax_param_id,
                                  value: param
                                }
                              })
                            }),
                            1
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("item_subject_taxes"),
                              expression: "errors.has('item_subject_taxes')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("item_subject_taxes")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "comments",
                              "label-placeholder": "Comments (3E-Fii)"
                            },
                            model: {
                              value: _vm.comments_3e_fii,
                              callback: function($$v) {
                                _vm.comments_3e_fii = $$v
                              },
                              expression: "comments_3e_fii"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "client_response",
                              "label-placeholder": "Client Responses"
                            },
                            model: {
                              value: _vm.client_responses,
                              callback: function($$v) {
                                _vm.client_responses = $$v
                              },
                              expression: "client_responses"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("client_response"),
                              expression: "errors.has('client_response')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("client_response")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "top_comments",
                              "label-placeholder": "Comments for ToP"
                            },
                            model: {
                              value: _vm.comments_for_top,
                              callback: function($$v) {
                                _vm.comments_for_top = $$v
                              },
                              expression: "comments_for_top"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("top_comments"),
                              expression: "errors.has('top_comments')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("top_comments")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm._l(_vm.customField, function(field, index) {
                    return _c(
                      "vs-col",
                      {
                        key: index,
                        staticClass: "mb-2",
                        attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                      },
                      [
                        _c(
                          "vx-input-group",
                          [
                            _c("vs-input", {
                              directives: [
                                {
                                  name: "validate",
                                  rawName: "v-validate",
                                  value: "required",
                                  expression: "`required`"
                                }
                              ],
                              attrs: {
                                type: field.text,
                                name: field.name,
                                "label-placeholder":
                                  "Custom Field " + (index + 1)
                              },
                              model: {
                                value: field.value,
                                callback: function($$v) {
                                  _vm.$set(field, "value", $$v)
                                },
                                expression: "field.value"
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
                  }),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vs-button",
                        {
                          staticClass: "mt-5",
                          attrs: { type: "gradient", button: "button" },
                          on: {
                            click: function($event) {
                              return _vm.addMoreFeild()
                            }
                          }
                        },
                        [_vm._v("Add More Custom Fields")]
                      )
                    ],
                    1
                  )
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "text-center",
                      attrs: { "vs-lg": "12", "vs-md": "12" }
                    },
                    [
                      _c(
                        "vs-col",
                        {
                          staticClass: "text-center",
                          attrs: { "vs-md": "12", "vs-lg": "12" }
                        },
                        [
                          _c(
                            "vs-button",
                            {
                              staticClass: "mt-5",
                              attrs: { button: "submit", type: "gradient" }
                            },
                            [_vm._v("Save")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        2
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/pages/Sales/AddSale.vue":
/*!********************************************************!*\
  !*** ./resources/js/src/views/pages/Sales/AddSale.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AddSale_vue_vue_type_template_id_6faed120___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AddSale.vue?vue&type=template&id=6faed120& */ "./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=template&id=6faed120&");
/* harmony import */ var _AddSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AddSale.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _AddSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AddSale_vue_vue_type_template_id_6faed120___WEBPACK_IMPORTED_MODULE_0__["render"],
  _AddSale_vue_vue_type_template_id_6faed120___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/Sales/AddSale.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AddSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./AddSale.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AddSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=template&id=6faed120&":
/*!***************************************************************************************!*\
  !*** ./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=template&id=6faed120& ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AddSale_vue_vue_type_template_id_6faed120___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./AddSale.vue?vue&type=template&id=6faed120& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/AddSale.vue?vue&type=template&id=6faed120&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AddSale_vue_vue_type_template_id_6faed120___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AddSale_vue_vue_type_template_id_6faed120___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);