(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[49],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      data: [],
      customField: [],
      sale_id: '',
      non_taxable_sales: '',
      export_value: '',
      person_non_taxable_sales: '',
      person_export_value: 0,
      customer_non_taxable_sales: '',
      customer_export_value: 0,
      total_taxable_value: 0
    };
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapState"])('customers', ['customer']), {
    averageRate: function averageRate() {
      return this.$store.state.averageRate;
    }
  }),
  watch: {
    person_non_taxable_sales: function person_non_taxable_sales(val, oldVal) {
      if (parseInt(val) >= 0) {
        this.person_export_value = parseFloat(val * 0.1).toFixed(2); // this.total_taxable_value += (taxable_value + (taxable_value * 0.1));
      } else {
        this.person_export_value = 0;
      }

      this.setTotalVat();
    },
    customer_non_taxable_sales: function customer_non_taxable_sales(val, oldVal) {
      if (parseInt(val) >= 0) {
        this.customer_export_value = parseFloat(val * 0.1).toFixed(2);
        var taxable_value = val * this.averageRate; // this.total_taxable_value += (taxable_value + (taxable_value * 0.1));
      } else {
        this.customer_export_value = 0;
      }

      this.setTotalVat();
    },
    non_taxable_sales: function non_taxable_sales(val, oldVal) {
      if (parseInt(val) >= 0) {
        var non_taxable_value = val * this.averageRate;
      }

      this.setTotalVat();
    },
    export_value: function export_value(val, oldVal) {
      if (parseInt(val) >= 0) {
        var non_taxable_value = val * this.averageRate; // this.total_taxable_value += (non_taxable_value);
      }

      this.setTotalVat();
    }
  },
  created: function created() {
    this.customer_id = localStorage.getItem('customer');
    this.$store.dispatch('getAverageRate');
    this.getCustomer(this.customer_id);
    this.editForm(this.$route.params.id);
  },
  methods: _objectSpread({
    setTotalVat: function setTotalVat() {
      var taxable_value = this.person_non_taxable_sales * this.averageRate;
      var person_non_taxable_val = taxable_value + taxable_value * 0.1;
      var taxable_value = this.customer_non_taxable_sales * this.averageRate;
      var customer_non_taxable_val = taxable_value + taxable_value * 0.1;
      var non_taxable_sale = this.non_taxable_sales * this.averageRate;
      var export_value = this.export_value * this.averageRate;
      this.total_taxable_value = person_non_taxable_val + customer_non_taxable_val + non_taxable_sale + export_value;
    },
    addMoreFeild: function addMoreFeild() {
      this.customField.push({
        name: 'additional_fields[]',
        value: '',
        type: 'text'
      });
    }
  }, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapActions"])({
    update: 'sales/updateSale',
    getCustomer: 'customers/getCustomer'
  }), {
    editForm: function editForm(routeId) {
      var _this = this;

      // var customer = this.findCustomer(id);
      axios.post('get-single-sale', {
        id: routeId
      }).then(function (res) {
        var sale = res.data.sale;
        _this.data = sale;
        _this.person_non_taxable_sales = _this.data.taxable_person_sales;
        _this.customer_non_taxable_sales = _this.data.cust_sales;
        _this.export_value = _this.data.vat;
        self = _this;
        self.customField = [];

        if (sale.additional_fields != null) {
          if (sale.additional_fields.length > 0) {
            sale.additional_fields.map(function (val, key) {
              self.customField.push({
                name: 'additional_fields[]',
                value: val,
                type: 'text'
              });
            });
          }
        }
      });
    },
    updateForm: function updateForm(e) {
      var _this2 = this;

      this.$validator.validateAll('editform').then(function (result) {
        if (result) {
          _this2.$vs.loading();

          var fd = new FormData(_this2.$refs.editform);

          _this2.update(fd).then(function (res) {
            console.log(res.data);

            if (res.data.status == 'success') {
              e.target.reset();

              _this2.errors.clear();

              _this2.editCustomerModal = false;

              _this2.$vs.notify({
                title: 'Success',
                text: 'Sale Updated Successfully',
                color: 'success',
                position: 'top-right'
              });

              _this2.$vs.loading.close();

              _this2.$router.back();
            }
          });
        }
      });
    }
  })
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=template&id=bc529cee&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=template&id=bc529cee& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "vx-card",
        {
          attrs: {
            title: "Edit Sale",
            subtitle:
              "Update Information Of Sale which tax will be managed by system",
            noShadow: "",
            noRadius: ""
          }
        },
        [
          _c(
            "form",
            {
              ref: "editform",
              attrs: { autocomplete: "off" },
              on: {
                submit: function($event) {
                  $event.preventDefault()
                  return _vm.updateForm($event)
                }
              }
            },
            [
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("input", {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.data.sale_id,
                                expression: "data.sale_id"
                              }
                            ],
                            attrs: {
                              type: "hidden",
                              name: "id",
                              "data-vv-scope": "editform"
                            },
                            domProps: { value: _vm.data.sale_id },
                            on: {
                              input: function($event) {
                                if ($event.target.composing) {
                                  return
                                }
                                _vm.$set(
                                  _vm.data,
                                  "sale_id",
                                  $event.target.value
                                )
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "account_code",
                              "data-vv-as": "Account Code",
                              "label-placeholder": "Account Code"
                            },
                            model: {
                              value: _vm.data.account_code,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "account_code", $$v)
                              },
                              expression: "data.account_code"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("account_code"),
                              expression: "errors.has('account_code')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("account_code")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "account_description",
                              "data-vv-as": "Account Description",
                              "label-placeholder": "Account Description"
                            },
                            model: {
                              value: _vm.data.account_description,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "account_description", $$v)
                              },
                              expression: "data.account_description"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("account_description"),
                              expression: "errors.has('account_description')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("account_description"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "accounting_reference",
                              "data-vv-as": "Account Reference",
                              "label-placeholder": "Account Reference"
                            },
                            model: {
                              value: _vm.data.accounting_reference,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "accounting_reference", $$v)
                              },
                              expression: "data.accounting_reference"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("accounting_reference"),
                              expression: "errors.has('accounting_reference')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("accounting_reference"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "signature_date",
                              "data-vv-as": "Signature Date",
                              "label-placeholder": "Signature Date"
                            },
                            model: {
                              value: _vm.data.signature_date,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "signature_date", $$v)
                              },
                              expression: "data.signature_date"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("signature_date"),
                              expression: "errors.has('signature_date')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("signature_date")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "branch_name",
                              "data-vv-as": "Branch Name",
                              "label-placeholder": "Branch#/Name"
                            },
                            model: {
                              value: _vm.data.branch_name,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "branch_name", $$v)
                              },
                              expression: "data.branch_name"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("branch_name"),
                              expression: "errors.has('branch_name')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("branch_name")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "tax_period",
                              "data-vv-as": "Tax Period",
                              "label-placeholder": "Tax Period"
                            },
                            model: {
                              value: _vm.data.tax_period,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "tax_period", $$v)
                              },
                              expression: "data.tax_period"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("tax_period"),
                              expression: "errors.has('tax_period')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("tax_period")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "invoice_date",
                              "data-vv-as": "Invoice Date",
                              "label-placeholder": "Invoice Date"
                            },
                            model: {
                              value: _vm.data.invoice_date,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "invoice_date", $$v)
                              },
                              expression: "data.invoice_date"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("invoice_date"),
                              expression: "errors.has('invoice_date')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("invoice_date")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "invoice_num",
                              "data-vv-as": "Invoice No. / Credit Note No.",
                              "label-placeholder":
                                "Invoice No./ Credit Note No."
                            },
                            model: {
                              value: _vm.data.invoice_num,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "invoice_num", $$v)
                              },
                              expression: "data.invoice_num"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("invoice_num"),
                              expression: "errors.has('invoice_num')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("invoice_num")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "client_name",
                              "data-vv-as": "Client Name",
                              "label-placeholder": "Client Name"
                            },
                            model: {
                              value: _vm.customer.name_english,
                              callback: function($$v) {
                                _vm.$set(_vm.customer, "name_english", $$v)
                              },
                              expression: "customer.name_english"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("client_name"),
                              expression: "errors.has('client_name')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("client_name")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "client_tin",
                              "data-vv-as": "Client TIN",
                              "label-placeholder": "Client TIN"
                            },
                            model: {
                              value: _vm.customer.tin_no,
                              callback: function($$v) {
                                _vm.$set(_vm.customer, "tin_no", $$v)
                              },
                              expression: "customer.tin_no"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("client_tin"),
                              expression: "errors.has('client_tin')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("client_tin")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "description",
                              "data-vv-as": "Description",
                              "label-placeholder": "Description"
                            },
                            model: {
                              value: _vm.data.description,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "description", $$v)
                              },
                              expression: "data.description"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("description"),
                              expression: "errors.has('description')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("description")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "quantity",
                              "data-vv-as": "Quantity",
                              "label-placeholder": "Quantity"
                            },
                            model: {
                              value: _vm.data.quantity,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "quantity", $$v)
                              },
                              expression: "data.quantity"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("quantity"),
                              expression: "errors.has('quantity')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("quantity")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "decimal",
                                expression: "`decimal`"
                              }
                            ],
                            attrs: {
                              name: "non_taxable_sales",
                              "data-vv-as": "Non-Taxable Sales",
                              "label-placeholder": "Non-Taxable Sales"
                            },
                            model: {
                              value: _vm.data.non_taxable_sales,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "non_taxable_sales", $$v)
                              },
                              expression: "data.non_taxable_sales"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("non_taxable_sales"),
                              expression: "errors.has('non_taxable_sales')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("non_taxable_sales")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "decimal",
                                expression: "`decimal`"
                              }
                            ],
                            attrs: {
                              name: "vat",
                              "data-vv-as": "Value Of Exports",
                              "label-placeholder": "Value of Exports/ 0% VAT"
                            },
                            model: {
                              value: _vm.data.vat,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "vat", $$v)
                              },
                              expression: "data.vat"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("vat"),
                              expression: "errors.has('vat')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("vat")))]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("br"),
              _vm._v(" "),
              _c("label", [_vm._v("Sales to Taxable Persons")]),
              _c("br"),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "decimal",
                                expression: "`decimal`"
                              }
                            ],
                            attrs: {
                              name: "taxable_person_sales",
                              "data-vv-as": "Non-Taxable Sales",
                              "label-placeholder": "Non-Taxable Sales"
                            },
                            model: {
                              value: _vm.person_non_taxable_sales,
                              callback: function($$v) {
                                _vm.person_non_taxable_sales = $$v
                              },
                              expression: "person_non_taxable_sales"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("taxable_person_sales"),
                              expression: "errors.has('taxable_person_sales')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("taxable_person_sales"))
                          )
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "person_export_value",
                              "label-placeholder": "VAT"
                            },
                            model: {
                              value: _vm.person_export_value,
                              callback: function($$v) {
                                _vm.person_export_value = $$v
                              },
                              expression: "person_export_value"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("br"),
              _vm._v(" "),
              _c("label", [_vm._v("Sales to Customers")]),
              _c("br"),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "cust_sales",
                              "data-vv-as": "Non-Taxable Sales",
                              "label-placeholder": "Non-Taxable Sales"
                            },
                            model: {
                              value: _vm.customer_non_taxable_sales,
                              callback: function($$v) {
                                _vm.customer_non_taxable_sales = $$v
                              },
                              expression: "customer_non_taxable_sales"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "customer_export_value",
                              "label-placeholder": "VAT"
                            },
                            model: {
                              value: _vm.customer_export_value,
                              callback: function($$v) {
                                _vm.customer_export_value = $$v
                              },
                              expression: "customer_export_value"
                            }
                          })
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              disabled: "",
                              name: "total_taxable_value",
                              "data-vv-as": "Total Taxable Value",
                              "label-placeholder": "Total Taxable Value"
                            },
                            model: {
                              value: _vm.total_taxable_value,
                              callback: function($$v) {
                                _vm.total_taxable_value = $$v
                              },
                              expression: "total_taxable_value"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("total_taxable_value"),
                              expression: "errors.has('total_taxable_value')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.errors.first("total_taxable_value"))
                          )
                        ]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "`required`"
                              }
                            ],
                            attrs: {
                              name: "item_subject_taxes",
                              "label-placeholder": "Itesm subject to taxes:"
                            },
                            model: {
                              value: _vm.data.taxes_subject,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "taxes_subject", $$v)
                              },
                              expression: "data.taxes_subject"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("item_subject_taxes"),
                              expression: "errors.has('item_subject_taxes')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("item_subject_taxes")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "comments_3e_fii",
                              "label-placeholder": "Comments (3E-Fii)"
                            },
                            model: {
                              value: _vm.data.comments,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "comments", $$v)
                              },
                              expression: "data.comments"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("comments_3e_fii"),
                              expression: "errors.has('comments_3e_fii')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("comments_3e_fii")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "client_responses",
                              "label-placeholder": "Client Responses"
                            },
                            model: {
                              value: _vm.data.client_response,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "client_response", $$v)
                              },
                              expression: "data.client_response"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("client_responses"),
                              expression: "errors.has('client_responses')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("client_responses")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vx-input-group",
                        [
                          _c("vs-input", {
                            attrs: {
                              name: "comments_for_top",
                              "label-placeholder": "Comments for ToP"
                            },
                            model: {
                              value: _vm.data.top_comments,
                              callback: function($$v) {
                                _vm.$set(_vm.data, "top_comments", $$v)
                              },
                              expression: "data.top_comments"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("comments_for_top"),
                              expression: "errors.has('comments_for_top')"
                            }
                          ],
                          staticClass: "text-danger"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("comments_for_top")))]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm._l(_vm.customField, function(field, index) {
                    return _c(
                      "vs-col",
                      {
                        key: index,
                        staticClass: "mb-2",
                        attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                      },
                      [
                        _c(
                          "vx-input-group",
                          [
                            _c("vs-input", {
                              directives: [
                                {
                                  name: "validate",
                                  rawName: "v-validate",
                                  value: "required",
                                  expression: "`required`"
                                }
                              ],
                              attrs: {
                                type: field.text,
                                name: field.name,
                                "label-placeholder":
                                  "Custom Field " + (index + 1)
                              },
                              model: {
                                value: field.value,
                                callback: function($$v) {
                                  _vm.$set(field, "value", $$v)
                                },
                                expression: "field.value"
                              }
                            })
                          ],
                          1
                        )
                      ],
                      1
                    )
                  }),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticClass: "mb-2",
                      attrs: { "vs-md": "12", "vs-lg": "4", "vs-sm": "12" }
                    },
                    [
                      _c(
                        "vs-button",
                        {
                          staticClass: "mt-5",
                          attrs: { type: "gradient", button: "button" },
                          on: {
                            click: function($event) {
                              return _vm.addMoreFeild()
                            }
                          }
                        },
                        [_vm._v("Add More Custom Fields")]
                      )
                    ],
                    1
                  )
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "vs-row",
                [
                  _c(
                    "vs-col",
                    {
                      staticClass: "text-center",
                      attrs: { "vs-lg": "12", "vs-md": "12" }
                    },
                    [
                      _c(
                        "vs-col",
                        {
                          staticClass: "text-center",
                          attrs: { "vs-md": "12", "vs-lg": "12" }
                        },
                        [
                          _c(
                            "vs-button",
                            {
                              staticClass: "mt-5",
                              attrs: { button: "submit", type: "gradient" }
                            },
                            [_vm._v("Save changes")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/pages/Sales/EditSale.vue":
/*!*********************************************************!*\
  !*** ./resources/js/src/views/pages/Sales/EditSale.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _EditSale_vue_vue_type_template_id_bc529cee___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EditSale.vue?vue&type=template&id=bc529cee& */ "./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=template&id=bc529cee&");
/* harmony import */ var _EditSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EditSale.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _EditSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _EditSale_vue_vue_type_template_id_bc529cee___WEBPACK_IMPORTED_MODULE_0__["render"],
  _EditSale_vue_vue_type_template_id_bc529cee___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/Sales/EditSale.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EditSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./EditSale.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EditSale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=template&id=bc529cee&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=template&id=bc529cee& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EditSale_vue_vue_type_template_id_bc529cee___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./EditSale.vue?vue&type=template&id=bc529cee& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Sales/EditSale.vue?vue&type=template&id=bc529cee&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EditSale_vue_vue_type_template_id_bc529cee___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EditSale_vue_vue_type_template_id_bc529cee___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);