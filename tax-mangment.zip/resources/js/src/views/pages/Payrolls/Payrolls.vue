<template>
    <div>
        <vx-card title="List of Payrolls">
            <template slot="actions">
                <vs-button type="border" :href="{url : `export-payroll/${customer_id}/${tax_id}`}" icon-pack="feather" icon="icon-download"></vs-button>
            </template>
            <vs-table search pagination max-items="6" :data="payrolls">
                <template slot="thead">
                    <vs-th>Created by</vs-th>
                    <vs-th>Employee Name</vs-th>
                    <vs-th>Employee No.</vs-th>
                    <vs-th>NSSF No.</vs-th>
                    <vs-th>Contract Type</vs-th>
                    <vs-th>Basic Salary</vs-th>
                    <vs-th>Bonus</vs-th>
                    <!-- <vs-th>Remarks</vs-th> -->
                    <vs-th v-show='is_officer == true'>Status</vs-th>
                    <vs-th>Current Status</vs-th>

                    <vs-th>Actions</vs-th>
                </template>
                <template slot-scope="{data}">
                    <vs-tr v-for="(tr,index) in data" :key="index">
                        <vs-td :data="tr.created_by.full_name">{{tr.created_by.full_name}}</vs-td>
                        <vs-td :data="tr.employee.name_english">{{tr.employee.name_english}}</vs-td>
                        <vs-td :data="tr.employee.employee_num">{{tr.employee.employee_num}}</vs-td>
                        <vs-td :data="tr.employee.nssf_num">{{tr.employee.nssf_num}}</vs-td>
                        <vs-td :data="tr.employee.contract_type">{{tr.employee.contract_type}}</vs-td>
                        <vs-td :data="tr.basic_salary">{{tr.basic_salary}}</vs-td>
                        <vs-td :data="tr.bonus">{{tr.bonus}}</vs-td>
                        <!-- <vs-td :data="tr.remark">{{tr.remark}}</vs-td> -->
                        
                        <vs-td v-show='is_officer == true' :data="tr.officer_confirmed">
                            <vs-switch v-if="editPermissionAccess(tr)" @click="statusUpdate(tr.payroll_id, tr.officer_confirmed)" v-model="tr.officer_confirmed"></vs-switch>
                            <vs-switch v-else @click="notAllowed('status')" v-model="tr.officer_confirmed == 1?true:false"> </vs-switch>
                        </vs-td>

                       
                        <vs-td>{{ currentTaxStatusForOfficer(tr) }}</vs-td>

                        <vs-td v-if="editPermissionAccess(tr)">
                            <vs-button :to="'edit-payroll/'+tr.payroll_id" size="small" type="border" icon-pack="feather" icon="icon-edit"></vs-button>
                            <vs-button :to="'payroll-detail/'+tr.payroll_id" size="small" icon-pack="feather" icon="icon-maximize-2" type="border"></vs-button>
                            <vs-button @click="deleteRecord(data[index])" size="small" type="border" icon-pack="feather" icon="icon-trash-2"></vs-button>
                        </vs-td>
                        <vs-td v-else>
                            <vs-button @click="notAllowed('edit')" size="small" type="border" icon-pack="feather" icon="icon-edit"></vs-button>
                            <vs-button :to="'payroll-detail/'+tr.payroll_id" size="small" icon-pack="feather" icon="icon-maximize-2" type="border"></vs-button>
                            <vs-button @click="notAllowed('delete')" size="small" type="border" icon-pack="feather" icon="icon-trash-2"></vs-button>
                        </vs-td>
                    </vs-tr>
                </template>
            </vs-table>
        </vx-card>


    </div>
</template>
<script>
import { mapState, mapActions,mapGetters } from 'vuex';
export default {
    inject : ['generatePassword'],
    data() {
        return {
            // switch1: true,
            editCustomerModal: false,
            customer_id: '',
            name_english: '',
            name_khmer: '',
            industry: '',
            tax_card_num: '',
            tin_no: '',
            email: '',
            telephone: '',
            address: '',
            street: '',
            village: '',
            muncipality: '',
            district: '',
            province: '',
            sangkat: '',
            group: '',
            incorporation_date: '',
            customField:[],
            tax_id: '',
            is_admin: false,
            is_supervisor: false,
            is_officer: false,
            selected_status: 1,
            statusList:[
                {text:'Pending',value:0},
                {text:'Approve',value:1},
                {text:'Un approve',value:2},
              ],

        };
    },
    computed: {
    	...mapState('payrolls/', ['payrolls'])

    },
    
    created() {
    	this.tax_id = this.$store.state.rootUrl.split('/')[2];
        this.getPayrolls(this.tax_id);
        this.customer_id = localStorage.getItem('customer');
       
       if (this.$store.state.AppActiveUser.type == 'Admin' || this.$store.state.AppActiveUser.type == 'Super Admin') {
            this.is_admin = true;
        }

        if (this.$store.state.AppActiveUser.type == 'Supervisor') {
            this.is_supervisor = true;
        }

        if (this.$store.state.AppActiveUser.type == 'Officer') {
            this.is_officer = true;
        }     
    },
    methods: {
        ...mapActions({
            getPayrolls: 'payrolls/getPayrolls',
            statusChange: 'taxes/statusUpdateSPP',
            statusChangeManagment: 'taxes/statusChangeManagment'
        }),

        changeManagementStatus(status, id, by){
            
            let data = {
                id: id,
                status: status,
                by: by,
                tax_id: this.tax_id,
                notify: this.$vs.notify,
                tax_type: 'payroll'
            };
            this.statusChangeManagment(data).then((res)=> {
               
            });
        },

        statusUpdate(id, status){

            let data = {
                id: id,
                tax_id: this.tax_id,
                notify: this.$vs.notify,
                type: 'payroll'
            };
            this.statusChange(data).then((res)=> {
               if(res.data.status != true){
                    var index = this.payrolls.findIndex(function(o){ return o.payroll_id == id;} );
                    if(res.data.response == 'undefined'){
                        this.payrolls[index].officer_confirmed = status; 
                    }else{
                        this.payrolls[index].officer_confirmed = res.data.response; 
                    }
               }
            });

        },

        currentTaxStatusForOfficer(tr){

                if(this.is_officer){
                    if(tr.officer_confirmed == 0 && tr.supervisor_confirmed == 0){
                        return 'Working In Progress';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 0){
                        return 'Submitted';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 1){
                        return 'Approved';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 2){
                        return 'Supervisor Reviewing';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 2){
                        return 'Rejected';
                    }
                }

                if(this.is_supervisor){
                    if(tr.officer_confirmed == 0 && tr.supervisor_confirmed == 0){
                        return 'Pending';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 0){
                        return 'Working In Progress';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 1){
                        return 'Approved';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 2){
                        return 'Review';
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 3){
                        return 'Rejected';
                    }
                }

                if(this.is_admin){
                    if(tr.supervisor_confirmed == 0 && tr.management_confirmed == 0){
                        return 'Pending';
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 0){
                        return 'Approved by Supervisor';
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 1){
                        return 'Approved';
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 2){
                        return 'Review';
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 3){
                        return 'Rejected';
                    }
                }
        },

        editPermissionAccess(tr){

                if(this.is_officer){
                    if(tr.officer_confirmed == 0 && tr.supervisor_confirmed == 0){
                        return true;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 0){
                        return true;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 1){
                        return false;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 2){
                        return false;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 3){
                        return true;
                    }

                    if(tr.officer_confirmed == 0 && tr.supervisor_confirmed == 3){
                        return true;
                    }
                }

                if(this.is_supervisor){
                    if(tr.officer_confirmed == 0 && tr.supervisor_confirmed == 0){
                        return false;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 0){
                        return true;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 1){
                        return true;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 2){
                        return true;
                    }

                    if(tr.officer_confirmed == 1 && tr.supervisor_confirmed == 3){
                        return true;
                    }
                    if(tr.officer_confirmed == 0 && tr.supervisor_confirmed == 3){
                        return false;
                    }
                }

                if(this.is_admin){
                    if(tr.supervisor_confirmed == 0 && tr.management_confirmed == 0){
                        return false;
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 0){
                        return true;
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 1){
                        return true;
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 2){
                        return true;
                    }

                    if(tr.supervisor_confirmed == 1 && tr.management_confirmed == 3){
                        return true;
                    }

                    if(tr.supervisor_confirmed == 0 && tr.management_confirmed == 3){
                        return false;
                    }
                }
        },

        notAllowed(opt){

            var msg;
            if(opt == 'status'){
                msg = 'You can\'t change payroll status, if Payroll is approved or supervisor reviewing it';
            }else if(opt == 'delete'){
                msg = 'You can\'t delete payroll, if Payroll is approved or supervisor reviewing it';
            }else if(opt == 'edit'){
                msg = 'You can\'t edit/update payroll, if Payroll is approved or supervisor reviewing it';
            }

            this.$vs.notify({
                text: msg,
                color: 'danger',
                position: 'top-right',
                time: 8000,
                icon: 'warning'
            });
        },

        deleteRecord(obj){
            this.$vs.loading();
            var fd = new FormData();
            fd.append('id', obj.payroll_id);
            fd.append('customer_id', obj.employee_id);
            fd.append('type', 'Payroll');
            axios.post('delete-spp', fd).then(res=>{
                if(res.data.status == true){
                    this.$vs.notify({
                        title: "Success",
                        text: res.data.msg,
                        color: 'success',
                        position: 'top-right'
                    });
                    this.$vs.loading.close();
                    this.getPayrolls(this.tax_id);
                }
            });
        },


        addMoreFeild () {
            this.customField.push({name : 'additional_field[]',value : '',type: 'text'});
        },

        updateCustomer(e) {
            this.$validator.validateAll('editform').then(result => {
                if (result) {
                    this.$vs.loading();
                    var fd = new FormData(this.$refs.editCustomerForm);
                    this.update(fd).then( (res) => {
                        if (res.data.status == 'success') {
                            e.target.reset();
                            this.errors.clear();
                            this.editCustomerModal = false;
                            this.$vs.notify({title:'Success',text:'Customer Updated Successfully',color:'success',position:'top-right'})
                            this.$vs.loading.close();
                            this.getCustomers();
                        }
                    })
                }
            })
        },
    }
}

</script>

<style type="text/css">
    .con-vs-popup .vs-popup {
        width: 1000px !important;
    }
    
</style>

