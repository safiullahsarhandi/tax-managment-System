export default {
	sales : [],
	sale : {},
}