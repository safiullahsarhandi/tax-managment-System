export default {
	admins : [],
	member : {},
}