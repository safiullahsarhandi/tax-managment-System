export default {
	taxes : [],
	tax : {},
	purchases_approval : 0,
	sales_approval : 0,
	payrolls_approval : 0,
	tax_team : [],
	parameters : [],
}