export default {
	setPurchases(state,purchases){
		state.purchases = purchases;
	},

	setPurchase(state,data){
		state.purchase = data;
	}
}