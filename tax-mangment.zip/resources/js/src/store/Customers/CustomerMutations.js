export default {
	setCustomers(state,customers){
		state.customers = customers;
	},
	setCustomer(state,customer){
		state.customer = customer;
	}
}