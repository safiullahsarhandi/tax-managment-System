export default {
	customers : [],
	owners : [],
	customer : {},
}