export default {
	customers : [],
	customer : {},
}