export default {
	customers : [],
	logs : [],
	owners : [],
	customer : {},
}