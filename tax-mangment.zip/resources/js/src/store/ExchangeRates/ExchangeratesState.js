export default {
	exchangerates : [],
}