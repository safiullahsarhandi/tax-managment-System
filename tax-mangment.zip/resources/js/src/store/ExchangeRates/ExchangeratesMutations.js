export default {
	setExchangeRates(state,rates){
		state.exchangerates = rates;
	},
}