export default {
	setPayrolls(state,payrolls){
		state.payrolls = payrolls;
	},

	setPayroll(state,data){
		state.payroll = data;
	},

}